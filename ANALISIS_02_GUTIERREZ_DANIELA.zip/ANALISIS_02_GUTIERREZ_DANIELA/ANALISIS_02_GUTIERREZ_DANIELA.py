#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 25 12:15:45 2020

@author: danielagubri
"""
import csv
from operator import itemgetter
import os

menu_selection = 0
backorexit = 0

#THE USER IS WELCOMED TO THE PLATFORM AND IS GIVEN THE INITIAL INDICATIONS
while True:

    input('''Welcome to Synergy Logistics Data Management System! 
(press enter to continue).
''')
    username = input(
        '''To start you will need to login with an administrator username. 
If you are not an administrator visit our clients website: www.synergylogistics.com

LOGIN
Enter username: ''')
    #THE USER ENTERS USERNAME AND THEN PASSWORD

    password = input("Enter password: ")
    login = False

    #IF THE USERNAME AND PASSWORD CORRESPOND TO ONE THE EXISTING ADMINISTRATOR ACCOUNTS THE USER WILL BE WELCOMED AND GIVEN THE CORRESPONDANT INTRUCTIONS TO CONTINUE, IF NOT, AN INSTRUCTION TO REFRESH AND TRY AGAIN WILL BE PRINTED

    adminlogins_list = [
        ["javier@admin.sylogistics.com", "2020", "Javier"],
        ["1", "1", "1"],
    ]

    if username == adminlogins_list[0][0] and password == adminlogins_list[0][
            1]:
        login = True
        os.system("clear")
        print("Welcome " + adminlogins_list[0][2] + "! We are glad you are here :D\n")

    elif username == adminlogins_list[1][0] and password == adminlogins_list[
            1][1]:
        login = True
        os.system("clear")
        print("Welcome " + adminlogins_list[1][2] +
              "! We are glad you are here :D\n")

    while login == True:
        print(
            '''The data in this system corresponds to the historic data of Synergy Logistics' Operations.
    ''')

        menu_selection = input(
            '''Indicate the information that you would like to visualize from the next menu:
      - Import-Export routes:  (1)
      - Type of transportation:  (2)
      - Total value of the imports and exports:  (3)
      - LOGOUT (4)\n\nEnter option: ''')

        menu_lists = ["1", "2", "3", "4"]

        if menu_selection in menu_lists:
            menu_selectioninput = True

        else:
            menu_selectioninput = False
            print('"', menu_selection, '"',
                  "is not a valid option from the Menu.")
            input("\nPress enter to try again ")
            os.system("clear")

        if menu_selectioninput == True and menu_selection == "1":
            listapaisesor = []
            listapaises = []
            
            #OPCION 1. IMPORTS-EXPORT ROUTES
            #IF THE USER SELECTS OPTION 1...
            
            with open ("synergy_logistics_database.csv", "r") as archivo_csv:
                lector = csv.DictReader(archivo_csv)
            #We create a list with the existing possible countries as a reference
   
                for linea in lector:
                    if linea["origin"] not in listapaisesor:
                        listapaisesor.append(linea["origin"])
                        
            #print ("Origin countries: ",listapaisesor) #These are the possible origin countries
            #print(len(listapaisesor)) #23
            
            with open ("synergy_logistics_database.csv", "r") as archivo_csv:
                lector = csv.DictReader(archivo_csv)
            
                for linea in lector:
                    if linea["destination"] not in listapaises:
                        listapaises.append(linea["destination"])
            
            #print ("Destination countries: ",listapaises) #These are the possible destination countries
            #print(len(listapaises)) #34
            
            contador = 0
            imports = []
            
            with open ("synergy_logistics_database.csv", "r") as archivo_csv:
                lector = csv.DictReader(archivo_csv)
            
                for pais in listapaises:
                    archivo_csv.seek(0)
                    for linea in lector:
                        if linea["destination"] == pais and linea["direction"] == "Imports":
                            contador += 1
                            
                    if contador > 0:
                        imports.append([contador, pais])
                        contador = 0
            
            #Cuenta en que cada país aparece como destino en las importaciones, porque el país que está importando es el de destino independientemente del origen
            #Lo acomodamos en orden descendente
            imports.sort(reverse=True)
            #print("IMPORTS: " ,imports)
            
            print ("TOP 10 OF DEMANDED ROUTES OF IMPORTS")
            print("-------------------------------------\n")
            
            #Hacemos funcion zip que nos permite ponerle un numero del 0 al 9 a los elementos de la lista
            for pais, i in zip(imports, range (0,10)):
                print ("Total routes with", pais[1], "as destination:", pais[0])
                
            
            contador2 = 0
            exports= []
            
            with open ("synergy_logistics_database.csv", "r") as archivo_csv:
                lector = csv.DictReader(archivo_csv)
            
                for pais in listapaisesor:
                    archivo_csv.seek(0)
                    for linea in lector:
                        if linea["origin"] == pais and linea["direction"] == "Exports":
                            contador2 += 1
                            
                    if contador2 > 0:
                        exports.append([contador2, pais])
                        contador2 = 0
            
            #Cuenta en que cada país aparece como origen en las exportaciones, porque el país que está exportando es el de origen independientemente del destino
            #Lo acomodamos en orden descendente
            exports.sort(reverse=True)
            #print("IMPORTS: " ,imports)
            
            print ("\nTOP 10 OF DEMANDED ROUTES OF EXPORTS")
            print("---------------------------------------\n")
            
            for pais, i in zip(exports, range (0,10)):
                print ("Total routes with", pais[1], "as origin:", pais[0])
                
            backorexit = input(
                "----------------------------------------------------------\nPress enter to go back the menu and visualize more information. Or enter '4' to LOGOUT: "
            )

            if backorexit == "4":
                os.system("clear")
                input(
                    "Thank you for using Synergy Logistics' Data Management System. \nWe hope to see you back soon! :D"
                )
                os.system("clear")
                break
            else:
                os.system("clear")
                
        elif menu_selectioninput == True and menu_selection == "2":
            value_sea = []
            value_air = []
            value_road = []
            value_rail = []
            
            with open ("synergy_logistics_database.csv", "r") as archivo_csv:
                lector = csv.DictReader(archivo_csv)
                
             #OPTION2. TYPE OF TRNSPORTATION
             #With bucles for we count and add to a list the total value generated by each kinf of transportation in the dictionary
                for linea in lector:
                    if linea["transport_mode"] == "Sea":
                        value_sea.append(int(linea["total_value"]))
                           
                    for linea in lector:
                        if linea["transport_mode"] == "Air":
                            value_air.append(int(linea["total_value"]))
            
                            for linea in lector:
                                if linea["transport_mode"] == "Road":
                                    value_road.append(int(linea["total_value"]))
                                    
                                    for linea in lector:
                                        if linea["transport_mode"] == "Rail":
                                            value_rail.append(int(linea["total_value"]))
                                    
                                            
            #Creamos un diccionario con las claves de los tipos de transporte y valores de suma correspondientes
            transportations = {"Sea": sum (value_sea) , "Air": sum (value_air), "Road": sum (value_road), "Rail": sum (value_rail)}
            #print(transportations)
            
            #Ordenamos el diccionario en orden descendente de acuerdo a los valores, para obtener los medios de transporte más usados
            transportations_des = sorted(transportations.items(), key = itemgetter(1), reverse= True)
            #print(transportations_des)
            

            
            #Sin importar si es exportación o importación, el transporte se ocupa y genera valor para la empresa
            print ("USAGE OF EACH TRANSPORTATION TYPE INCLUDING IMPORTS AND EXPORTS")
            print("-----------------------------------------------------------------\n")
            
            
            for i in transportations_des: 
                print("Total value for", i[0],"transportation: ", i[1])
                
            backorexit = input(
                "----------------------------------------------------------\nPress enter to go back the menu and visualize more information. Or enter '4' to LOGOUT: "
            )

            if backorexit == "4":
                os.system("clear")
                input(
                    "Thank you for using Synergy Logistics' Data Management System. \nWe hope to see you back soon! :D"
                )
                os.system("clear")
                break
            else:
                os.system("clear")
                
        elif menu_selectioninput == True and menu_selection == "3":
            
            #OPTION 3. TOTAL VALUE OF THE IMPORTS AND EXPORTS.
            #We create a list to add the sum of the value generated by each countrie separated by import/export and destination/origin
            
            lista_datos = []
            with open ("synergy_logistics_database.csv", "r") as archivo_csv:
                lector = csv.reader(archivo_csv)
                
                for linea in lector:
                    lista_datos.append(linea)
            
            #IMPORTS COUNTRIES DESTINATION
            
            sumador = 0
            paises_destination = [] 
            suma_paises = []
            
            for pais in lista_datos:
                if pais[1] == "Imports":
                    pais_actual = [pais[3]]
                
                    if pais_actual not in paises_destination:
                        for movimiento in lista_datos:
                            if pais_actual == [movimiento[3]]:
                                sumador += int(movimiento[9])
                                
                        paises_destination.append(pais_actual)
                        suma_paises.append([sumador,pais[3]])
                        sumador= 0
                        
            
            suma_paises.sort(reverse=True)
            
            print ("\nTOP 80% OF COUNTRIES (DESTINATION) THAT GENERATE THE MOST VALUE OF IMPORTS")
            print("--------------------------------------------------------------------------\n")
            #el 80% son 9 (total11*.80)
            for pais, i in zip(suma_paises, range (0,9)):
                print ("Total value generated by", pais[1], ":", pais[0])
                
            
            #EXPORTS COUNTRIES ORIGIN
                
            lista_datos2 = []
            with open ("synergy_logistics_database.csv", "r") as archivo_csv:
                lector = csv.reader(archivo_csv)
                
                for linea in lector:
                    lista_datos.append(linea)
            
            
            sumador2 = 0
            paises_origin = [] 
            suma_paises2 = []
            
            for pais in lista_datos:
                if pais[1] == "Exports":
                    pais_actual = [pais[2]]
                
                    if pais_actual not in paises_origin:
                        for movimiento in lista_datos:
                            if pais_actual == [movimiento[2]]:
                                sumador2 += int(movimiento[9])
                                
                        paises_origin.append(pais_actual)
                        suma_paises2.append([sumador2,pais[2]])
                        sumador2 = 0
                        
            
            suma_paises2.sort(reverse=True)
            
            #With the zip function we only print the top 80% of the countries list
            print ("\nTOP 80% OF COUNTRIES (ORIGIN) THAT GENERATE THE MOST VALUE OF EXPORTS")
            print("---------------------------------------------------------------------\n")
            #el 80% son 16 (total20*.80)
            
            for pais, i in zip(suma_paises2, range (0,16)):
                print ("Total value generated by", pais[1], ":", pais[0])
                
            backorexit = input(
                "----------------------------------------------------------\nPress enter to go back the menu and visualize more information. Or enter '4' to LOGOUT: "
            )

            if backorexit == "4":
                os.system("clear")
                input(
                    "Thank you for using Synergy Logistics' Data Management System. \nWe hope to see you back soon! :D"
                )
                os.system("clear")
                break
            else:
                os.system("clear")
                
        elif menu_selectioninput == True and menu_selection == "4":
            os.system("clear")
            input(
                "Thank you for using Synergy Logistics' Data Management System. \nWe hope to see you back soon! :D"
            )
            os.system("clear")
            break
        
    else:
        if menu_selection == "4" or backorexit == "4":
            menu_selection = 0
            backorexit = 0
            os.system("clear")

        else:
            input(
                "\n*** Wrong username or password. If you are an administrator press enter to try again or contact your manager.*** "
            )
            os.system("clear")
            
