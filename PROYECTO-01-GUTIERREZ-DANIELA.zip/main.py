from lists import lifestore_products
from lists import lifestore_sales
from lists import lifestore_searches
import os

menu_selection = 0
backorexit = 0

#THE USER IS WELCOMED TO THE PLATFORM AND IS GIVEN THE INITIAL INDICATIONS
while True:

    input('''Welcome to LifeStore's Data Management System! 
(press enter to continue).
''')
    username = input(
        '''To start you will need to login with an administrator username. 
If you are not an administrator visit our clients website: www.lifestoreshop.com

LOGIN
Enter username: ''')
    #THE USER ENTERS USERNAME AND THEN PASSWORD

    password = input("Enter password: ")
    login = False

    #IF THE USERNAME AND PASSWORD CORRESPOND TO ONE THE EXISTING ADMINISTRATOR ACCOUNTS THE USER WILL BE WELCOMED AND GIVEN THE CORRESPONDANT INTRUCTIONS TO CONTINUE, IF NOT, AN INSTRUCTION TO REFRESH AND TRY AGAIN WILL BE PRINTED

    adminlogins_list = [
        ["07061998@admin.lifestore.com", "Admin986532", "Daniela"],
        ["07211968@admin.lifestore.com", "Admin235689", "Javier"],
        ["07231991@admin.lifestore.com", "Admin563499", "Gabriela"],
        ["1", "1", "1"],
        ["45678776@client.lifestore.com", "Miley2020", "Maribel"]
    ]

    if username == adminlogins_list[0][0] and password == adminlogins_list[0][
            1]:
        login = True
        os.system("clear")
        print("Welcome " + adminlogins_list[0][2] + "!")

    elif username == adminlogins_list[1][0] and password == adminlogins_list[
            1][1]:
        login = True
        os.system("clear")
        print("Welcome " + adminlogins_list[1][2] +
              "! We are glad you are here :D\n")

    elif username == adminlogins_list[2][0] and password == adminlogins_list[
            2][1]:
        login = True
        os.system("clear")
        print("Welcome " + adminlogins_list[2][2] + "!\n")

    elif username == adminlogins_list[3][0] and password == adminlogins_list[
            3][1]:
        login = True
        os.system("clear")
        print("Welcome " + adminlogins_list[3][2] + "!\n")

    elif username == adminlogins_list[4][0] and password == adminlogins_list[
            4][1]:
        os.system("clear")
        login = "client"

    while login == True:
        print(
            '''The data in this system corresponds to the list of products and sales of the first semester of 2020.
    ''')

        menu_selection = input(
            '''Indicate the information that you would like to visualize from the next menu:
      - Most sold and searched products (1)
      - Least sold and searched products (2)
      - Products by client review (3)
      - Total income and sales (4)
      - LOGOUT (5)\n\nEnter option: ''')

        menu_lists = ["1", "2", "3", "4", "5"]

        if menu_selection in menu_lists:
            menu_selectioninput = True

        else:
            menu_selectioninput = False
            print('"', menu_selection, '"',
                  "is not a valid option from the Menu.")
            input("\nPress enter to try again ")
            os.system("clear")

        if menu_selectioninput == True and menu_selection == "1":
            #We create a list to organize the products and an auxiliar variable for sorting the list.

            CantidadVenta = [[1, 0], [2, 0], [3, 0], [4, 0], [5, 0], [6, 0],
                             [7, 0], [8, 0], [9, 0], [10, 0], [11, 0], [12, 0],
                             [13, 0], [14, 0], [15, 0], [16, 0], [17, 0],
                             [18, 0], [19, 0], [20, 0], [21, 0], [22, 0],
                             [23, 0], [24, 0], [25, 0], [26, 0], [27, 0],
                             [28, 0], [29, 0], [30, 0], [31, 0], [32, 0],
                             [33, 0], [34, 0], [35, 0], [36, 0], [37, 0],
                             [38, 0], [39, 0], [40, 0], [41, 0], [42, 0],
                             [43, 0], [44, 0], [45, 0], [46, 0], [47, 0],
                             [48, 0], [49, 0], [50, 0], [51, 0], [52, 0],
                             [53, 0], [54, 0], [55, 0], [56, 0], [57, 0],
                             [58, 0], [59, 0], [60, 0], [61, 0], [62, 0],
                             [63, 0], [64, 0], [65, 0], [66, 0], [67, 0],
                             [68, 0], [69, 0], [70, 0], [71, 0], [72, 0],
                             [73, 0], [74, 0], [75, 0], [76, 0], [77, 0],
                             [78, 0], [79, 0], [80, 0], [81, 0], [82, 0],
                             [83, 0], [84, 0], [85, 0], [86, 0], [87, 0],
                             [88, 0], [89, 0], [90, 0], [91, 0], [92, 0],
                             [93, 0], [94, 0], [95, 0], [96, 0]]

            CantidadVentaAux = [0, 0]

            #We count with 'for' the quantity of sales that are registered in the lifestore_sales list.
            for i in range(0, len(lifestore_sales)):
                if (lifestore_sales[i][4] == 0):
                    CantidadVenta[
                        lifestore_sales[i][1] -
                        1][1] = CantidadVenta[lifestore_sales[i][1] - 1][1] + 1
            #We sort the list obtained in ascending order.
            for i in range(0, 96):
                for j in range(0, 96):
                    if (CantidadVenta[i][1] < CantidadVenta[j][1]):
                        CantidadVentaAux[0] = CantidadVenta[i]
                        CantidadVenta[i] = CantidadVenta[j]
                        CantidadVenta[j] = CantidadVentaAux[0]
            print("")
            print(
                "THESE ARE THE TOP MOST SOLD PRODUCTS:\n--------------------------------------------- "
            )
            print("")
            #print(CantidadVenta)
            for i in range(0, 50):
                if (CantidadVenta[95 - i][1] > 0):
                    print(i + 1, ".PRODUCT:",
                          lifestore_products[CantidadVenta[95 - i][0] - 1][1],
                          "\n   SALES:", CantidadVenta[95 - i][1], "\n")

                #We create a list to organize the products and an auxiliar variable for sorting the list.

            CantidadBusqueda = [[1, 0], [2, 0], [3, 0], [4, 0], [5, 0], [6, 0],
                                [7, 0], [8, 0], [9, 0], [10, 0], [11, 0],
                                [12, 0], [13, 0], [14, 0], [15, 0], [16, 0],
                                [17, 0], [18, 0], [19, 0], [20, 0], [21, 0],
                                [22, 0], [23, 0], [24, 0], [25, 0], [26, 0],
                                [27, 0], [28, 0], [29, 0], [30, 0], [31, 0],
                                [32, 0], [33, 0], [34, 0], [35, 0], [36, 0],
                                [37, 0], [38, 0], [39, 0], [40, 0], [41, 0],
                                [42, 0], [43, 0], [44, 0], [45, 0], [46, 0],
                                [47, 0], [48, 0], [49, 0], [50, 0], [51, 0],
                                [52, 0], [53, 0], [54, 0], [55, 0], [56, 0],
                                [57, 0], [58, 0], [59, 0], [60, 0], [61, 0],
                                [62, 0], [63, 0], [64, 0], [65, 0], [66, 0],
                                [67, 0], [68, 0], [69, 0], [70, 0], [71, 0],
                                [72, 0], [73, 0], [74, 0], [75, 0], [76, 0],
                                [77, 0], [78, 0], [79, 0], [80, 0], [81, 0],
                                [82, 0], [83, 0], [84, 0], [85, 0], [86, 0],
                                [87, 0], [88, 0], [89, 0], [90, 0], [91, 0],
                                [92, 0], [93, 0], [94, 0], [95, 0], [96, 0]]

            CantidadBusquedaAux = [0, 0]

            #We count with 'for' the quantity of searches that are registered in the lifestore_searches list.

            for i in range(0, len(lifestore_searches)):
                CantidadBusqueda[lifestore_searches[i][1] - 1][
                    1] = CantidadBusqueda[lifestore_searches[i][1] - 1][1] + 1

            #We sort the list obtained in ascending order.

            for i in range(0, 96):
                for j in range(0, 96):
                    if (CantidadBusqueda[i][1] < CantidadBusqueda[j][1]):
                        CantidadBusquedaAux[0] = CantidadBusqueda[i]
                        CantidadBusqueda[i] = CantidadBusqueda[j]
                        CantidadBusqueda[j] = CantidadBusquedaAux[0]

            #We indicate with a 'for' the indexes we want to print and print them. (Product name and number of searches)

            print("")
            print(
                "THESE ARE THE TOP MOST SEARCHED PRODUCTS:\n--------------------------------------------- "
            )
            print("")
            #print(CantidadBusqueda)
            for i in range(0, 96):
                if (CantidadBusqueda[95 - i][1] > 0):
                    print(
                        i + 1, ".PRODUCT:",
                        lifestore_products[CantidadBusqueda[95 - i][0] - 1][1],
                        "\n   SEARCHES:", CantidadBusqueda[95 - i][1], "\n")
            backorexit = input(
                "----------------------------------------------------------\nPress enter to go back the menu and visualize more information. Or enter '5' to LOGOUT: "
            )
            if backorexit == "5":
                os.system("clear")
                input(
                    "Thank you for using Lifestore's Data Management System. \nWe hope to see you back soon! :D"
                )
                os.system("clear")
                break

            else:
                os.system("clear")

        elif menu_selectioninput == True and menu_selection == "2":
            CantidadVenta = [[1, 0], [2, 0], [3, 0], [4, 0], [5, 0], [6, 0],
                             [7, 0], [8, 0], [9, 0], [10, 0], [11, 0], [12, 0],
                             [13, 0], [14, 0], [15, 0], [16, 0], [17, 0],
                             [18, 0], [19, 0], [20, 0], [21, 0], [22, 0],
                             [23, 0], [24, 0], [25, 0], [26, 0], [27, 0],
                             [28, 0], [29, 0], [30, 0], [31, 0], [32, 0],
                             [33, 0], [34, 0], [35, 0], [36, 0], [37, 0],
                             [38, 0], [39, 0], [40, 0], [41, 0], [42, 0],
                             [43, 0], [44, 0], [45, 0], [46, 0], [47, 0],
                             [48, 0], [49, 0], [50, 0], [51, 0], [52, 0],
                             [53, 0], [54, 0], [55, 0], [56, 0], [57, 0],
                             [58, 0], [59, 0], [60, 0], [61, 0], [62, 0],
                             [63, 0], [64, 0], [65, 0], [66, 0], [67, 0],
                             [68, 0], [69, 0], [70, 0], [71, 0], [72, 0],
                             [73, 0], [74, 0], [75, 0], [76, 0], [77, 0],
                             [78, 0], [79, 0], [80, 0], [81, 0], [82, 0],
                             [83, 0], [84, 0], [85, 0], [86, 0], [87, 0],
                             [88, 0], [89, 0], [90, 0], [91, 0], [92, 0],
                             [93, 0], [94, 0], [95, 0], [96, 0]]

            CantidadVentaAux = [0, 0]

            #We count with 'for' the quantity of sales that are registered in the lifestore_sales list.

            for i in range(0, len(lifestore_sales)):
                if (lifestore_sales[i][4] == 0):
                    CantidadVenta[
                        lifestore_sales[i][1] -
                        1][1] = CantidadVenta[lifestore_sales[i][1] - 1][1] + 1

            #We sort the list obtained in ascending order.

            for i in range(0, 96):
                for j in range(0, 96):
                    if (CantidadVenta[i][1] < CantidadVenta[j][1]):
                        CantidadVentaAux[0] = CantidadVenta[i]
                        CantidadVenta[i] = CantidadVenta[j]
                        CantidadVenta[j] = CantidadVentaAux[0]

            CantidadBusqueda = [[1, 0], [2, 0], [3, 0], [4, 0], [5, 0], [6, 0],
                                [7, 0], [8, 0], [9, 0], [10, 0], [11, 0],
                                [12, 0], [13, 0], [14, 0], [15, 0], [16, 0],
                                [17, 0], [18, 0], [19, 0], [20, 0], [21, 0],
                                [22, 0], [23, 0], [24, 0], [25, 0], [26, 0],
                                [27, 0], [28, 0], [29, 0], [30, 0], [31, 0],
                                [32, 0], [33, 0], [34, 0], [35, 0], [36, 0],
                                [37, 0], [38, 0], [39, 0], [40, 0], [41, 0],
                                [42, 0], [43, 0], [44, 0], [45, 0], [46, 0],
                                [47, 0], [48, 0], [49, 0], [50, 0], [51, 0],
                                [52, 0], [53, 0], [54, 0], [55, 0], [56, 0],
                                [57, 0], [58, 0], [59, 0], [60, 0], [61, 0],
                                [62, 0], [63, 0], [64, 0], [65, 0], [66, 0],
                                [67, 0], [68, 0], [69, 0], [70, 0], [71, 0],
                                [72, 0], [73, 0], [74, 0], [75, 0], [76, 0],
                                [77, 0], [78, 0], [79, 0], [80, 0], [81, 0],
                                [82, 0], [83, 0], [84, 0], [85, 0], [86, 0],
                                [87, 0], [88, 0], [89, 0], [90, 0], [91, 0],
                                [92, 0], [93, 0], [94, 0], [95, 0], [96, 0]]

            CantidadBusquedaAux = [0, 0]
            #We count with 'for' the quantity of searches that are registered in the lifestore_searches list.
            for i in range(0, len(lifestore_searches)):
                CantidadBusqueda[lifestore_searches[i][1] - 1][
                    1] = CantidadBusqueda[lifestore_searches[i][1] - 1][1] + 1
            #We sort the list obtained in ascending order.
            for i in range(0, 96):
                for j in range(0, 96):
                    if (CantidadBusqueda[i][1] < CantidadBusqueda[j][1]):
                        CantidadBusquedaAux[0] = CantidadBusqueda[i]
                        CantidadBusqueda[i] = CantidadBusqueda[j]
                        CantidadBusqueda[j] = CantidadBusquedaAux[0]
            #We indicate with a 'for' the indexes we want to print and print them. (Product name by category of the products with no sales)
            print("")
            print(
                "THESE ARE THE PRODUCTS WITH NO SALES BY CATEGORY:\n--------------------------------------------- "
            )
            print("")
            for i in range(0, len(CantidadVenta)):
                if (CantidadVenta[i][1] == 0):
                    print(i + 1, ".CATEGORY:",
                          lifestore_products[CantidadVenta[i][0] - 1][3],
                          "PRODUCT:",
                          lifestore_products[CantidadVenta[i][0] - 1][1], "\n")

            #We indicate with a 'for' the indexes we want to print and print them. (Product name by category of the products with no searches)

            print("")
            print(
                "THESE ARE THE PRODUCTS WITH NO SEARCHES BY CATEGORY:\n--------------------------------------------- "
            )
            print("")
            for i in range(0, len(CantidadBusqueda)):
                if (CantidadBusqueda[i][1] == 0):
                    print(i + 1, ".CATEGORY:",
                          lifestore_products[CantidadBusqueda[i][0] - 1][3],
                          ".PRODUCT:",
                          lifestore_products[CantidadBusqueda[i][0] - 1][1],
                          "\n")
            backorexit = input(
                "----------------------------------------------------------\nPress enter to go back the menu and visualize more information. Or enter '5' to LOGOUT: "
            )
            if backorexit == "5":
                os.system("clear")
                input(
                    "Thank you for using Lifestore's Data Management System. \nWe hope to see you back soon! :D"
                )
                os.system("clear")
                break
            else:
                os.system("clear")

        elif menu_selectioninput == True and menu_selection == "3":
            #We create a list to organize the products for sorting the list.

            CantidadVentaCD = [[1, 0], [2, 0], [3, 0], [4, 0], [5, 0], [6, 0],
                               [7, 0], [8, 0], [9, 0], [10, 0], [11, 0],
                               [12, 0], [13, 0], [14, 0], [15, 0], [16, 0],
                               [17, 0], [18, 0], [19, 0], [20, 0], [21, 0],
                               [22, 0], [23, 0], [24, 0], [25, 0], [26, 0],
                               [27, 0], [28, 0], [29, 0], [30, 0], [31, 0],
                               [32, 0], [33, 0], [34, 0], [35, 0], [36, 0],
                               [37, 0], [38, 0], [39, 0], [40, 0], [41, 0],
                               [42, 0], [43, 0], [44, 0], [45, 0], [46, 0],
                               [47, 0], [48, 0], [49, 0], [50, 0], [51, 0],
                               [52, 0], [53, 0], [54, 0], [55, 0], [56, 0],
                               [57, 0], [58, 0], [59, 0], [60, 0], [61, 0],
                               [62, 0], [63, 0], [64, 0], [65, 0], [66, 0],
                               [67, 0], [68, 0], [69, 0], [70, 0], [71, 0],
                               [72, 0], [73, 0], [74, 0], [75, 0], [76, 0],
                               [77, 0], [78, 0], [79, 0], [80, 0], [81, 0],
                               [82, 0], [83, 0], [84, 0], [85, 0], [86, 0],
                               [87, 0], [88, 0], [89, 0], [90, 0], [91, 0],
                               [92, 0], [93, 0], [94, 0], [95, 0], [96, 0]]

            #We create a list to organize the products for sorting the list by review and an auxiliar variable.

            Reviews = [[1, 0], [2, 0], [3, 0], [4, 0], [5, 0], [6, 0], [7, 0],
                       [8, 0], [9, 0], [10, 0], [11, 0], [12, 0], [13, 0],
                       [14, 0], [15, 0], [16, 0], [17, 0], [18, 0], [19, 0],
                       [20, 0], [21, 0], [22, 0], [23, 0], [24, 0], [25, 0],
                       [26, 0], [27, 0], [28, 0], [29, 0], [30, 0], [31, 0],
                       [32, 0], [33, 0], [34, 0], [35, 0], [36, 0], [37, 0],
                       [38, 0], [39, 0], [40, 0], [41, 0], [42, 0], [43, 0],
                       [44, 0], [45, 0], [46, 0], [47, 0], [48, 0], [49, 0],
                       [50, 0], [51, 0], [52, 0], [53, 0], [54, 0], [55, 0],
                       [56, 0], [57, 0], [58, 0], [59, 0], [60, 0], [61, 0],
                       [62, 0], [63, 0], [64, 0], [65, 0], [66, 0], [67, 0],
                       [68, 0], [69, 0], [70, 0], [71, 0], [72, 0], [73, 0],
                       [74, 0], [75, 0], [76, 0], [77, 0], [78, 0], [79, 0],
                       [80, 0], [81, 0], [82, 0], [83, 0], [84, 0], [85, 0],
                       [86, 0], [87, 0], [88, 0], [89, 0], [90, 0], [91, 0],
                       [92, 0], [93, 0], [94, 0], [95, 0], [96, 0]]

            ReviewsAux = [0, 0]

            #We count with a'for' the number of sales that are registered in the list lifestore_sales.
            for i in range(0, len(lifestore_sales)):
                CantidadVentaCD[
                    lifestore_sales[i][1] -
                    1][1] = CantidadVentaCD[lifestore_sales[i][1] - 1][1] + 1

            #We count with a 'for' the sum of sales registered in the list lifestore_sales.

            for i in range(0, len(lifestore_sales)):
                Reviews[lifestore_sales[i][1] - 1][1] = Reviews[
                    lifestore_sales[i][1] - 1][1] + lifestore_sales[i][2]

            for i in range(0, len(Reviews)):
                if (CantidadVentaCD[i][1] > 0):
                    Reviews[i][1] = Reviews[i][1] / CantidadVentaCD[i][1]

            #We sort the data obtained in ascending order.

            for i in range(0, 96):
                for j in range(0, 96):
                    if (Reviews[i][1] < Reviews[j][1]):
                        ReviewsAux[0] = Reviews[i]
                        Reviews[i] = Reviews[j]
                        Reviews[j] = ReviewsAux[0]

            #We indicate with a 'for' the indexes we want to print and print them from 1 to 20. (Product name and average score of reviews)

            print("")
            print(
                "THESE ARE THE TOP 20 PRODUCTS BY REVIEW (AVERAGE ON A SCALE FROM 1 TO 5):\n--------------------------------------------- "
            )
            print("")
            for i in range(0, 20):
                print(i + 1, ".PRODUCT:",
                      lifestore_products[Reviews[95 - i][0] - 1][1],
                      "\n   SCORE:", Reviews[95 - i][1], "\n")

            #We indicate with a 'for' the indexes we want to print and print them from 1 to 20. (Product name and average score of reviews)

            print("")
            print(
                "THESE ARE THE WORST 20 PRODUCTS BY REVIEW (AVERAGE ON A SCALE FROM 1 TO 5):\n--------------------------------------------- "
            )
            i = 0
            j = 0
            while (j < 20):
                if (Reviews[i][1] > 0):
                    print(j + 1, ".PRODUCT:",
                          lifestore_products[Reviews[i][0] - 1][1],
                          "\n   SCORE:", Reviews[i][1], "\n")
                    j = j + 1
                i = i + 1
            backorexit = input(
                "----------------------------------------------------------\nPress enter to go back the menu and visualize more information. Or enter '5' to LOGOUT: "
            )
            if backorexit == "5":
                os.system("clear")
                input(
                    "Thank you for using Lifestore's Data Management System. \nWe hope to see you back soon! :D"
                )
                os.system("clear")
                break
            else:
                os.system("clear")

        elif menu_selectioninput == True and menu_selection == "4":
            print("")
            print(
                "THIS IS THE TOTAL INCOME FROM THE SALES OF 2020:\n--------------------------------------------- "
            )

            prices = []  #we create list
            for i in range(0, len(
                    lifestore_products)):  #product price so we can multiply it
                prices.append(lifestore_products[i][2])
            months = []
            for i in range(0, len(lifestore_sales)):
                id_product = lifestore_sales[i][
                    1] - 1  #we omit those who got no sales
                date_month = lifestore_sales[i][3].split("/")[1]
                if len(months) == 0:
                    months.append([prices[id_product], date_month])

                else:
                    count = False
                    for m in months:
                        if m[1] == date_month:
                            m[0] += prices[id_product]
                            count = True

                    if count == False:
                        months.append([prices[id_product], date_month])

            aux = [0, 0]
            for i in range(0, len(months)):
                for j in range(0, len(months)):
                    if (months[i][1] < months[j][1]):
                        aux[0] = months[i]
                        months[i] = months[j]
                        months[j] = aux[0]

            #We asign the month of the years to the list to print them later

            for i in range(0, len(months)):
                months_list = [["01", "January"], ["02", "February"],
                               ["03", "March"], ["04", "April"], ["05", "May"],
                               ["06", "June"], ["07", "July"],
                               ["08", "August"], ["09", "September"],
                               ["10", "October"], ["11", "November"],
                               ["12", "December"]]

                if months[i][1] == months_list[i][0]:
                    months[i][1] = months_list[i][1]

                elif months[i][1] == "11":
                    months[i][1] = "November"

                print(months[i][1], "total income: "
                      "$ " + str(months[i][0]), "MXN")

            countby12 = [0] * 12
            prices = []

            for i in range(0, len(lifestore_products)):
                prices.append(lifestore_products[i][2])

            for i in range(0, len(lifestore_sales)):
                id = lifestore_sales[i][1]
                extracted_month = lifestore_sales[i][3].split("/")[1]
                countby12[int(extracted_month) - 1] += prices[id]

            lenght = len(lifestore_products)
            sales = [0] * lenght

            for s in lifestore_sales:
                idx = s[1]
                sales[idx - 1] += 1

            sales1 = []
            total_sales = 0  #acumulator

            for i in range(0, len(lifestore_products)):
                name = lifestore_products[i][1]
                count = sales[i]
                price = lifestore_products[i][2]
                total_price = price * count
                total_sales = total_sales + total_price
                newlist = [name, count, price, total_price, total_sales]
                sales.append(newlist)

            print("\nTotal income of the year: $", total_sales, "MXN\n")
            print("Average of monthly income: $", total_sales / 12, "MXN\n")

            backorexit = input(
                "----------------------------------------------------------\nPress enter to go back the menu and visualize more information. Or enter '5' to LOGOUT: "
            )

            if backorexit == "5":
                os.system("clear")
                input(
                    "Thank you for using Lifestore's Data Management System. \nWe hope to see you back soon! :D"
                )
                os.system("clear")
                break
            else:
                os.system("clear")

        elif menu_selectioninput == True and menu_selection == "5":
            os.system("clear")
            input(
                "Thank you for using Lifestore's Data Management System. \nWe hope to see you back soon! :D"
            )
            os.system("clear")
            break

    if login == "client":
        print("Hello " + adminlogins_list[4][2] + "!")
        input(
            "\nThis is the administrators Data Management System for LifeStore. Please visit our clients website if you would like to shop our products or obtain a service: www.lifestoreshop.com "
        )

        os.system("clear")

    else:
        if menu_selection == "5" or backorexit == "5":
            menu_selection = 0
            backorexit = 0
            os.system("clear")

        else:
            input(
                "\n*** Wrong username or password. If you are an administrator press enter to try again or contact your manager.*** "
            )
            os.system("clear")
